
## CONTRIBUTE

{% set donation_link = config.theme.donation_link or "#" %}

[Ajudar a manter o projeto e trazer novas features<br>Help maintain the project and bring new features]({{ donation_link }})

## UPCOMMING FEATURES 

- Economic calendar (UNDER DEVELOPMENT)

![ECONOMIC CALENDAR](image/features/econimic_calendar.png)

- News feed

![NEWS FEED](image/features/news_feed.png)

## IQOPTION API SUPPORTED BY COMMUNITY

This api is intended to be an open source project to communicate with iqOption site.
this is a no official repository, it means it is maintained by community

Esta API é destinada a ser um projeto de código aberto para se comunicar com o site da iqOption.
este é um repositório não oficial, significa que é mantido pela comunidade

Esta API está destinada a ser un proyecto de código abierto para comunicarse con el sitio de IqIoption.
este es un repositorio no oficial, significa que es mantenido por la comunidad

<div style="text-align:center;">
	<h2> Idiomas | Languages </h2>
	<a href="pt/">
		<img src="image/flags/br.png "
		alt="Português" width="50" height="50" />
	</a>
	<a href="es/">
		<img src="image/flags/es.png "
		alt="Espanol" width="50" height="50" />
	</a>
	<a href="en/">
		<img src="image/flags/en.png "
		alt="English" width="50" height="50" />
	</a>
</div>
